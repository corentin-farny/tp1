


const passwordController = require('../controllers/passwordController');

module.exports = (server) => {
    server.route("/password")
    .get(passwordController.readAllPassword) // Get all Passwords
    .post(passwordController.createAPassword); // Create a Password

    server.route("/password/:password_id") // req.params.Password_id
    .get(passwordController.readAPassword) // Get one Passwords
    .put(passwordController.updateAPassword) // Update one Password
    .delete(passwordController.deleteAPassword); // Delete one Password
}
