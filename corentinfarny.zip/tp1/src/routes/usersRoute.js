


const usersController = require('../controllers/usersController');

module.exports = (server) => {
    server.route("/users")
    .get(usersController.readAllUsers) // Get all userss
    .post(usersController.createAUsers); // Create a users

    server.route("/users/:users_id") // req.params.users_id
    .get(usersController.readAUsers) // Get one userss
    .put(usersController.updateAUsers) // Update one users
    .delete(usersController.deleteAUsers); // Delete one post
}
