const mongoose = require('mongoose');

const Schema = mongoose.Schema;

let usersSchema = new Schema({
    title: {
        type: String,
        required: true,
    },
    content: {
        type: String,
        required: true
    },
    created_at: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Users', usersSchema);
