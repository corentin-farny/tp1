const Comments = require('../models/commentsModel');

// Get all comments
exports.readAllComments = (req, res) => {
    Comments.find({}, (error, comments) => {
        if(error){
            res.status(500);
            console.log(error);
            res.end({message: "Erreur serveur."});
        }
        else {
            res.status(200);
            res.json({
                count : comments.length,
                comments
            });
        }
    });
}

// Create a comment
exports.createAComments = (req, res) => {
    // {
    //     title: "Mon premeir article",
    //     content: "toto"
    // }
    let newcComments = new Comments(req.body);

    newComments.save((error, comment) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(201);
            res.json(comment);
        }
    });
}


// Get a comment
exports.readAComments = (req, res) => {
    Comments.findById(req.params.comment_id, (error, comment) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(comment);
        }
    });
}

// Update a comment
exports.updateAComments = (req, res) => {
    Comments.findByIdAndUpdate(req.params.comment_id, req.body, {new: true}, (error, comment) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(comment);
        }
    });
}

// Delete a comment
exports.deleteAComments = (req, res) => {
    Comments.findByIdAndDelete(req.params.comment_id, (error) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json({message: "Commentaire supprimé"});
        }
    });
}
