const Users = require('../models/usersModel');

// Get all users
exports.readAllUsers = (req, res) => {
    Users.find({}, (error, users) => {
        if(error){
            res.status(500);
            console.log(error);
            res.end({message: "Erreur serveur."});
        }
        else {
            res.status(200);
            res.json({
                count : users.length,
                users
            });
        }
    });
}

// Create a users
exports.createAUsers = (req, res) => {
    // {
    //     title: "Mon premeir article",
    //     content: "toto"
    // }
    let newUsers = new Users(req.body);

    newUsers.save((error, users) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(201);
            res.json(users);
        }
    });
}


// Get a users
exports.readAUsers = (req, res) => {
    Users.findById(req.params.users_id, (error, users) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(users);
        }
    });
}

// Update a users
exports.updateAUsers = (req, res) => {
    Users.findByIdAndUpdate(req.params.users_id, req.body, {new: true}, (error, users) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(users);
        }
    });
}

// Delete a users
exports.deleteAUsers = (req, res) => {
    Users.findByIdAndDelete(req.params.users_id, (error) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json({message: "utilisateur supprimé"});
        }
    });
}
