const Pawword = require('../models/usersModel');

// Get all users
exports.readAllPassword = (req, res) => {
    Password.find({}, (error, password) => {
        if(error){
            res.status(500);
            console.log(error);
            res.end({message: "Erreur serveur."});
        }
        else {
            res.status(200);
            res.json({
                count : password.length,
                password
            });
        }
    });
}

// Create a users
exports.createAPassword = (req, res) => {
    // {
    //     title: "Mon premeir article",
    //     content: "toto"
    // }
    let newPassword = new Password(req.body);

    newPassword.save((error, password) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(201);
            res.json(password);
        }
    });
}


// Get a users
exports.readAPassword = (req, res) => {
    Password.findById(req.params.password_id, (error, password) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(password);
        }
    });
}

// Update a users
exports.updateAPassword = (req, res) => {
    Password.findByIdAndUpdate(req.params.password_id, req.body, {new: true}, (error, password) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json(password);
        }
    });
}

// Delete a users
exports.deleteAPassword = (req, res) => {
    Users.findByIdAndDelete(req.params.passwords_id, (error) => {
        if (error) {
            res.status(500);
            console.log(error);
            res.end({ message: "Erreur serveur." });
        }
        else {
            res.status(200);
            res.json({message: "utilisateur supprimé"});
        }
    });
}
